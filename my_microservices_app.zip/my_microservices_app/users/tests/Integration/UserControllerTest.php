<?php

namespace App\Tests\Integration;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;
use Symfony\Component\Messenger\Transport\InMemoryTransport;

class UserControllerTest extends WebTestCase
{
    public function testCreateUser()
    {
        $client = static::createClient();

        $data = [
            'email' => 'test@example.com',
            'firstName' => 'John',
            'lastName' => 'Doe'
        ];

        $client->request('POST', '/users', [], [], ['CONTENT_TYPE' => 'application/json'], json_encode($data));

        $this->assertEquals(201, $client->getResponse()->getStatusCode());

        // Assert message dispatched
        /** @var InMemoryTransport $transport */
        $transport = self::$container->get('messenger.transport.async');
        $messages = $transport->getSent();
        $this->assertCount(1, $messages);
    }
}
