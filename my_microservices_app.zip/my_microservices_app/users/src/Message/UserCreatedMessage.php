<?php

namespace App\Message;

class UserCreatedMessage
{
    private int $userId;
    private string $email;
    private string $firstName;
    private string $lastName;

    public function __construct(int $userId, string $email, string $firstName, string $lastName)
    {
        $this->userId = $userId;
        $this->email = $email;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
    }

    // Getters...
}
