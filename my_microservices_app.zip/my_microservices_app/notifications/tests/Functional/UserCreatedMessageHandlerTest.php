<?php

namespace App\Tests\Functional;

use App\Message\UserCreatedMessage;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;
use Symfony\Component\Messenger\MessageBusInterface;
use Psr\Log\LoggerInterface;

class UserCreatedMessageHandlerTest extends KernelTestCase
{
    public function testMessageHandling()
    {
        self::bootKernel();

        $bus = self::$container->get(MessageBusInterface::class);
        $logger = self::$container->get(LoggerInterface::class);

        // Mock logger
        $logger->expects($this->once())
            ->method('info')
            ->with($this->stringContains('User Created: ID=1'));

        $message = new UserCreatedMessage(1, 'test@example.com', 'John', 'Doe');
        $bus->dispatch($message);
    }
}
