<?php

namespace App\Tests\Unit\Message;

use App\Message\UserCreatedMessage;
use PHPUnit\Framework\TestCase;

class UserCreatedMessageTest extends TestCase
{
    public function testMessageCreation()
    {
        $message = new UserCreatedMessage(1, 'test@example.com', 'John', 'Doe');

        $this->assertEquals(1, $message->getUserId());
        $this->assertEquals('test@example.com', $message->getEmail());
        $this->assertEquals('John', $message->getFirstName());
        $this->assertEquals('Doe', $message->getLastName());
    }
}
