<?php

namespace App\MessageHandler;

use App\Message\UserCreatedMessage;
use Symfony\Component\Messenger\Handler\MessageHandlerInterface;
use Psr\Log\LoggerInterface;

class UserCreatedMessageHandler implements MessageHandlerInterface
{
    private LoggerInterface $logger;

    public function __construct(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }

    public function __invoke(UserCreatedMessage $message)
    {
        echo "string"; exit;
        $data = sprintf(
            "User Created: ID=%d, Email=%s, FirstName=%s, LastName=%s",
            $message->getUserId(),
            $message->getEmail(),
            $message->getFirstName(),
            $message->getLastName()
        );

        $this->logger->info($data);
    }
}
